.. CICE-Consortium documentation master file, created by
   sphinx-quickstart on Thu Jun 29 13:47:09 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

===========================================
CICE Documentation 
===========================================

.. toctree::
   :numbered:
   :maxdepth: 2

   intro/index.rst
   science_guide/index.rst
   user_guide/index.rst
   developer_guide/index.rst
   cice_index.rst
   zreferences.rst

* :ref:`search`

