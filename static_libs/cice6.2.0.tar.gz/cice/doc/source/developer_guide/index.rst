.. CICE-Consortium documentation master file, created by
   sphinx-quickstart on Thu Jun 29 13:47:09 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. _developer_guide:

Developer Guide
-----------------

.. toctree::
   :maxdepth: 3

   dg_about.rst
   dg_dynamics.rst
   dg_driver.rst
   dg_forcing.rst
   dg_icepack.rst
   dg_scripts.rst
   dg_tools.rst
   dg_other.rst

