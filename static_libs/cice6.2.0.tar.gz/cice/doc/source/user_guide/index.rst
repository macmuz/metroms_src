.. CICE-Consortium documentation master file, created by
   sphinx-quickstart on Thu Jun 29 13:47:09 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. _user_guide:

User Guide
-----------------

.. toctree::
   :maxdepth: 3
 
   ug_implementation.rst
   ug_running.rst
   ug_testing.rst
   ug_case_settings.rst
   ug_troubleshooting.rst

