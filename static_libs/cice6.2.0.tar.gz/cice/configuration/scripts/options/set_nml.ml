
oceanmixed_ice = .true.
ocn_data_type = 'ncar'
ocn_data_format = 'nc'
ocn_data_dir    = 'ICE_MACHINE_INPUTDATA/CICE_data/forcing/gx1/CESM/MONTHLY'
oceanmixed_file = 'ocean_forcing_clim_2D_gx1.20210330.nc'

