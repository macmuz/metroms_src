# Test         Grid    PEs        Sets    BFB-compare
#restart        gx1     4x4         droundrobin,short
#restart        gx1     8x4         droundrobin,short
#restart        gx1     12x4         droundrobin,short
#restart        gx1     16x4         droundrobin,short
#restart        gx1     20x4         droundrobin,short
#restart        gx1     24x4         droundrobin,short
#restart        gx1     28x4         droundrobin,short
#restart        gx1     32x4         droundrobin,short
restart        gx1     32x2         droundrobin,short
restart        gx1     32x3         droundrobin,short
restart        gx1     32x1         droundrobin,short

restart        gx1     33x4         droundrobin,short
restart        gx1     34x4         droundrobin,short
restart        gx1     35x4         droundrobin,short
restart        gx1     36x4         droundrobin,short
#restart        gx1     40x4       droundrobin,short
