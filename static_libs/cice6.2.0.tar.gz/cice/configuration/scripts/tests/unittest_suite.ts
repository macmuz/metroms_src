# Test         Grid    PEs        Sets    BFB-compare
unittest       gx3     1x1        helloworld
unittest       gx3     1x1        calchk

