.. CICE-Consortium documentation master file, created by
   sphinx-quickstart on Thu Jun 29 13:47:09 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. _user_guide_withmodels:

Use in Other Models
-------------------------

.. toctree::
   :maxdepth: 3

   lg_overview.rst
   lg_protocols.rst
   lg_sequence.rst
   lg_interfaces.rst




