:tocdepth: 3

.. _acknowledgements:

Acknowledgements
=============================

This work has been completed through the CICE Consortium and its members with funding 
through the

- Department of Energy (Los Alamos National Laboratory)

- Department of Defense (Navy)

- Department of Commerce (National Oceanic and Atmospheric Administration)

- National Science Foundation (the National Center for Atmospheric Research)

- Environment and Climate Change Canada.

Special thanks are due to participants from these institutions and many others 
who contributed to previous versions of CICE or Icepack.


