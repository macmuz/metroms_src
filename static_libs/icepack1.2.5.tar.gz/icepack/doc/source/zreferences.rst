
*******************
References
*******************

.. rubric:: References

.. bibliography:: master_list.bib
   :cited:
   :style: plain
