# Test         Grid    PEs        Sets    BFB-compare
smoke          col     1x1        diag1,run1year
smoke          col     1x1        debug,run1year
restart        col     1x1        diag1
